
This is Lobo, the Java-based web browser.

To run Lobo look for its Program Group or
desktop launcher. In case you just downloaded
the Lobo files and not the installer, try

  java -jar lobo.jar

The Lobo browser is released under a GPLv2 license.
See LICENSE.txt for additional details.
For information on how to obtain the source code,
see http://lobobrowser.org/sourcecode.jsp

Note that lobo-pub.jar (the extensions API) is 
released under a permissive FreeBSD style license, 
which is compatible with the GPL.

Home Page: http://lobobrowser.org
Contact: http://lobobrowser.org/contact.jsp
